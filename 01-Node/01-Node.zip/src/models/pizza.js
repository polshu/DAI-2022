class Pizza {
    Id;
    Nombre;
    LibreGluten;
    Importe;
    Descripcion;
}

export default Pizza;





