# API de Test (Get / Post)
Ejemplo de API de testing (talba test) utilizando express que accede a SQL Server, utiliza env.

----------------
## Modulos Instalados
- npm i dotenv
- npm i express
- npm i cors
- npm i http-status-codes
- npm i mssql
- npm i nodemon
----------------
## Base de datos
> Ejecutar los scripts de creacion de la base de datos.

- 01 - CreateLoginAndUser
- 02 - CreateTableAndData

## Para iniciar el web server.
> npm run server

## Rutas
- La API se encuentra en 
    > http://localhost:8080/api/test

## Cambios con respecto a la version anterior
- El log de Errores se guarda en LOG_ROOT_FOLDER ("c:\Temp\")
