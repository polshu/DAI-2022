# API de Test (Get / Post)
Ejemplo de API de testing (Tabla test) utilizando express que accede a la base de datos, utiliza env.

----------------
## Modulos Instalados
- npm i dotenv
- npm i express
- npm i cors
- npm i http-status-codes
- npm i mssql
- npm i nodemon
----------------
## Base de datos
> Ejecutar los scripts de creacion de la base de datos.

- 01 - CreateLoginAndUser
- 02 - CreateTableAndData

## Para iniciar el web server.
> npm run serverlite
> npm run server

## Rutas
- La API se encuentra en 
    > http://localhost:8080/api/test

## Cambios con respecto a la version anterior
- El log de Errores se guarda en LOG_ROOT_FOLDER ("c:\Temp\")

## Intalar el token
- ngrok config add-authtoken <tu token>

## Iniciar el tunner con NGROK
- Abrir una terminal y ejecutar:
    > ngrok.exe update (si es que hace falta, por unica vez)
    > ngrok http 8080  (el 8080 es el puerto en que decidi escuchar con el Webserver)

