import express from "express";
import cors    from "cors";

// Variables/Constantes del Modulo
const app  = express();
const port = 8080;

// Inclusion de los Middlewares
app.use(cors());                              // Agrego el middleware de CORS
app.use(express.json());                      // Agrego el middleware para parsear y comprender JSON

app.get('/api/test', async (req, res) => {
  let respuesta;
  const data = { id : 10, nombre : 'Monica Galindo'};
  respuesta = res.status(200).json(data);
  return respuesta;
});

// Levanto el servidor WEB (pongo a escuchar)
app.listen(port, () => {
  console.log(`"server" escuchando el en el puerto ${port} (http://localhost:${port}/)`);
});
