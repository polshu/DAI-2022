import { Router} from 'express';
import TestService from '../services/test-services.js';
import { ReasonPhrases, StatusCodes} from 'http-status-codes';

const router = Router();
const primaryService = new TestService();

router.get('', async (req, res) => {
  let respuesta;
  console.log(`TestRouter -> get`)
  const entityArray = await primaryService.getAll();
  if (entityArray!=null){
    respuesta = res.status(StatusCodes.OK).json(entityArray);
  } else {
    respuesta = res.status(StatusCodes.INTERNAL_SERVER_ERROR).send(`Error interno.`);
  }

  return respuesta;
});


router.post('', async (req, res) => {
  let entity = req.body;
  console.log(`TestRouter -> post`)
  const registrosAfectados = await primaryService.insert(entity);

  return res.status(StatusCodes.CREATED).json(registrosAfectados);
});

export default router;
