class Test {
    id;
	data_type_int;
	data_type_varchar;
	data_type_bit;
	data_type_datetime;
	data_type_decimal;
	data_type_float;
}

export default Test;





