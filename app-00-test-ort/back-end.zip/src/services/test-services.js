import config from './../../dbconfig.js';
import sql from 'mssql';
import logHelper from './../modules/log-helper.js';

const tableName = 'test';
const className = 'TestService';

class TestService {
    getAll = async () => {
        let returnArray = null;
        console.log(`TestService -> getAll()`)
        try {
            let pool   = await sql.connect(config);
            let result = await pool.request().query(`SELECT * FROM ${tableName}`);
            returnArray = result.recordset;
        }
        catch (error) {
            logHelper.logError(`${tableName}->getAll`, error);
        }
        return returnArray;
    }


    insert = async (entity) => {
        let rowsAffected = 0;
        console.log(`TestService -> insert(entity)`)
        try {
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pdata_type_int'     , sql.Int       , entity?.data_type_int ?? 0)
                .input('pdata_type_varchar' , sql.VarChar   , entity?.pdata_type_varchar ?? '')
                .input('pdata_type_bit'     , sql.Bit       , entity?.data_type_bit ?? false)
                .input('pdata_type_datetime', sql.DateTime  , entity?.data_type_datetime ?? '2000-01-01T00:00:00.000Z')
                .input('pdata_type_decimal' , sql.Decimal   , entity?.data_type_decimal ?? 0.0)
                .input('pdata_type_float'   , sql.Float     , entity?.data_type_float ?? 0.0)
                .query(`INSERT INTO ${tableName} (
                            data_type_int, 
                            data_type_varchar, 
                            data_type_bit, 
                            data_type_datetime,
                            data_type_decimal,
                            data_type_float
                        ) VALUES (
                            @pdata_type_int, 
                            @pdata_type_varchar, 
                            @pdata_type_bit, 
                            @pdata_type_datetime,
                            @pdata_type_decimal,
                            @pdata_type_float
                        )`);
            rowsAffected = result.rowsAffected;
        } catch (error) {
            logHelper.logError(`${tableName}->insert`, error);
        }
        return rowsAffected;
    }
}

export default TestService;
