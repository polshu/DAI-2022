USE [master]
GO
--
-- Primero hay que crear la base de datos 'DAI-Pizzas'
--

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE [name] = N'Test')
BEGIN
	PRINT 'Creando Login de la Base DAI-Test'
	CREATE LOGIN [Test] WITH 
		PASSWORD=N'Test2024', 
		DEFAULT_DATABASE=[DAI-Test], 
		CHECK_EXPIRATION=OFF, 
		CHECK_POLICY=OFF
END
GO

USE [DAI-Test]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE [name] = N'Test')
BEGIN
	PRINT 'Creando User'
	CREATE USER [Test] FOR LOGIN [Test]
	ALTER ROLE [db_owner] ADD MEMBER [Test]
END 
GO
