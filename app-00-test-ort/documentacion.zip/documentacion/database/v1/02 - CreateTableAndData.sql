USE [DAI-Test]
GO
/****** Object:  Table [dbo].[test]    Script Date: 2/15/2024 8:51:21 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[test](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[data_type_int] [int] NULL,
	[data_type_varchar] [varchar](250) NULL,
	[data_type_bit] [bit] NULL,
	[data_type_datetime] [datetime] NULL,
	[data_type_decimal] [decimal](18, 4) NULL,
	[data_type_float] [float] NULL,
 CONSTRAINT [PK_test] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[test] ON 
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (1, 5, N'a', 1, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(1027.0567 AS Decimal(18, 4)), 1000.25)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (2, 10, N'b', 0, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(2054.1134 AS Decimal(18, 4)), 2000.5)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (3, 15, N'c', 1, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(3081.1701 AS Decimal(18, 4)), 3000.75)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (4, 20, N'd', 0, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(4108.2268 AS Decimal(18, 4)), 4001)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (5, 25, N'e', 1, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(5135.2835 AS Decimal(18, 4)), 5001.25)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (6, 30, N'f', 0, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(6162.3402 AS Decimal(18, 4)), 6001.5)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (7, 35, N'g', 1, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(7189.3969 AS Decimal(18, 4)), 7001.75)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (8, 40, N'h', 0, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(8216.4536 AS Decimal(18, 4)), 8002)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (9, 45, N'i', 1, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(9243.5103 AS Decimal(18, 4)), 9002.25)
GO
INSERT [dbo].[test] ([id], [data_type_int], [data_type_varchar], [data_type_bit], [data_type_datetime], [data_type_decimal], [data_type_float]) VALUES (10, 50, N'j', 0, CAST(N'2024-02-15T20:46:49.417' AS DateTime), CAST(10270.5670 AS Decimal(18, 4)), 10002.5)
GO
SET IDENTITY_INSERT [dbo].[test] OFF
GO