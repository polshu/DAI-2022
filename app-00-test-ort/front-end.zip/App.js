//App.js
import React, { useState } from 'react';
import { SafeAreaView, View, Text, TextInput, Image, TouchableOpacity, Alert, StyleSheet, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import axios from 'axios';

export default function App() {
  //const [rootURL, setRootURL] = useState('http://localhost:8080');
  //const [rootURL, setRootURL] = useState('http://10.0.2.2:8080');
  const [rootURL, setRootURL] = useState('https://adder-valued-man.ngrok-free.app');
  //const [rootURL, setRootURL] = useState('http://192.168.56.1:8080'); // ipconfig /all
  
  const [endPointResult, setEndPointResult] = useState('');
  //const baseUrl = Platform.OS === 'android' ? 'http://10.0.2.2' : 'http://localhost';
  //console.log('baseUrl', baseUrl);
  const handleLocalApiGet = async () => {
    const endPoint = `${rootURL}/api/test`;
    console.log(`handleLocalApiGet: ${endPoint}`);
    try {
      console.log(`1`);
      const response = await axios.get(endPoint,  {
                                                    timeout: 3000,
                                                    headers: {
                                                      Accept: 'application/json',
                                                    },
                                                  }
        );
      console.log(`2`);
      // Comprueba si la respuesta tiene un código de estado 200 (éxito)
      if (response.status === 200) {
          console.log(`3`);
          console.log('response.data:');
          let resultString = JSON.stringify(response.data);
          setEndPointResult(resultString);
          // Si todo es exitoso, retorna true
      } else {
          console.log(`4`);
          // Si el servidor respondió con un código de estado diferente de 200, retorna false
          console.log('response.status:');
          setEndPointResult(response.status);
          
      }
    } catch (error) {
        console.log(`5`);
        // Si se produce un error durante la solicitud, maneja el error y retorna false
        console.error('Error:', error.toString());
        setEndPointResult('Error');
        //Alert.alert('Información', error);
    }
  };

  const handleLocalApiPost = async () => {
    console.log(`handleLocalApiPost`);
    Alert.alert('Información', 'Not Implemented');
  }

  const handleClearResponse = async () => {
    setEndPointResult('');
  }

  
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      <Text>
          TEST de APIs dentro de la red de ORT
      </Text>
      <TextInput
          style={styles.input}
          placeholder="API Url"
          onChangeText={(text) => setRootURL(text)}
          value={rootURL}
      />
      
      <TouchableOpacity style={styles.loginButton} onPress={handleLocalApiGet}>
        <Text style={styles.buttonText}>LOCAL API - GET</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.loginButton} onPress={handleLocalApiPost}>
        <Text style={styles.buttonText}>LOCAL API - POST</Text>
      </TouchableOpacity>

      <ScrollView>
        <Text>
            EndPoint Respuesta:
        </Text>
        <Text>
            {endPointResult}
        </Text>
      </ScrollView>

      <TouchableOpacity style={styles.clearButton} onPress={handleClearResponse}>
        <Text style={styles.buttonText}>CLEAR</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
  },
  imageLogo: {
    marginBottom: 30,
    resizeMode :'cover',
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 15,
  },
  button :{
    flex:1,
    flexDirection:'row-reverse',
    backgroundColor: "#aaf0d1"
  },
  loginButton: {
    width: '100%',
    backgroundColor: '#007AFF',
    borderRadius: 5,
    paddingVertical: 12,
    marginTop: 15,
    marginBottom: 15,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
  },
  clearButton: {
    width: '100%',
    backgroundColor: '#AAAAAA',
    borderRadius: 5,
    paddingVertical: 12,
    marginTop: 15,
    marginBottom: 15,
  },
});
