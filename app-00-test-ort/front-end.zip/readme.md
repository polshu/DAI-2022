# API de Test (Get / Post)
Ejemplo de API de testing (talba test) utilizando express que accede a SQL Server, utiliza env.
- npm install -g expo-cli
- npm install expo@latest
- npx expo install --fix (actualiza todas las dependencias)
- npx create-expo-app ejemplo-app

----------------
## Modulos Instalados
- npm i expo-status-bar
- npm i axios
----------------

## Para iniciar la app
> npx expo start --tunnel

## Para iniciar la app
1) Una app de react-native que acceden a apis locales desarrolladas con node en la misma maquina (Get/Post).
2) Una app de react-native que acceden a apis locales desarrolladas con node en otra maquina del labo.
3) Una app de react-native que acceden a apis externas por ejemplo OMDB.
4) Una app de react-native que acceden a apis locales desarrolladas con node, y desde node se accede a apis externas por ejemplo OMDB.
Todo esto desde el celu.


--https://bobbyhadz.com/blog/handle-timeouts-in-axios#how-to-handle-timeouts-when-using-axios
--https://bobbyhadz.com/blog/axios-change-base-url

-- https://dashboard.ngrok.com/cloud-edge/domains
-- pablo.ulman@ort.edu.ar (gmail)



# Setup
Pasos a segior para utilzar ngrok.
- ir a "https://ngrok.com/" registrarse.

- npm install expo@latest
- npx expo install --fix (actualiza todas las dependencias)
- npx create-expo-app ejemplo-app

